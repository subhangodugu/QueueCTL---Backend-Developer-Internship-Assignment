# queuectl — CLI Job Queue (Python)

A minimal production-grade CLI background job queue with retries, exponential backoff, and a Dead Letter Queue (DLQ).

## Features
- Enqueue shell-command jobs
- Persistent storage (SQLite)
- Multiple worker threads
- Retry on failure with exponential backoff (`delay = base ** attempts`)
- DLQ for permanently failed jobs
- Config via CLI (`backoff_base`, `default_max_retries`)
- Graceful worker shutdown

## Requirements
- Python 3.8+
- `pip install -r requirements.txt`

## Setup
```bash
git clone <your-repo-url>
cd QueueCTL-Backend-Developer-Internship-Assignment
pip install -r requirements.txt
```

## Quick usage examples

Start workers (foreground):
```bash
python queuectl.py worker start --count 2
# press Ctrl+C to stop gracefully
```

Enqueue a job:
```bash
python queuectl.py enqueue '{"id":"job1","command":"sleep 2 && echo hi"}'
```

List jobs:
```bash
python queuectl.py list
python queuectl.py list --state pending
```

View status:
```bash
python queuectl.py status
```

DLQ:
```bash
python queuectl.py dlq list
python queuectl.py dlq retry job-id
```

Config:
```bash
python queuectl.py config set backoff_base 3
python queuectl.py config set default_max_retries 5
python queuectl.py config get backoff_base
```

## Testing
Run the provided test script:
```bash
chmod +x run_tests.sh
./run_tests.sh
```

## Notes
- Uses SQLite for persistence (file `queue.db` created in current directory)
- Exponential backoff can grow quickly; consider capping delay for production
