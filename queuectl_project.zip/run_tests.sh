#!/usr/bin/env bash
set -e
pip install -r requirements.txt
rm -f queue.db || true
# Start worker in background
python queuectl.py worker start --count 2 &
WORKER_PID=$!
echo "Started worker background process PID $WORKER_PID"
sleep 1
python queuectl.py enqueue '{"id":"job-success","command":"echo Hello && sleep 1"}'
python queuectl.py enqueue '{"id":"job-fail","command":"nonexistent_command","max_retries":2}'
echo "Waiting 15 seconds for processing and retries..."
sleep 15
python queuectl.py status
python queuectl.py dlq list || true
python queuectl.py dlq retry job-fail || true
sleep 3
python queuectl.py dlq list || true
kill $WORKER_PID || true
echo "Test script complete"
