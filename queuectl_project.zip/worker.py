# worker.py
import threading
import time
import subprocess
from db import claim_next_pending, update_job_on_success, update_job_on_failure, get_config
from db import _now_iso
import signal
import sys

_stop_event = threading.Event()

class WorkerThread(threading.Thread):
    def __init__(self, name, poll_interval=1.0):
        super().__init__(name=name, daemon=True)
        self.poll_interval = poll_interval
        self.active_job = None

    def run(self):
        base_backoff = float(get_config('backoff_base', '2'))
        while not _stop_event.is_set():
            job = claim_next_pending(_now_iso())
            if not job:
                time.sleep(self.poll_interval)
                continue
            self.active_job = job
            job_id = job['id']
            command = job['command']
            attempts = job['attempts'] or 0
            max_retries = job['max_retries'] or int(get_config('default_max_retries', '3'))
            attempts += 1
            try:
                print(f"[{self.name}] Executing job {job_id}: {command} (attempt {attempts}/{max_retries})")
                completed = subprocess.run(command, shell=True)
                if completed.returncode == 0:
                    update_job_on_success(job_id)
                    print(f"[{self.name}] Job {job_id} completed successfully.")
                else:
                    err = f"exit_code:{completed.returncode}"
                    update_job_on_failure(job_id, attempts, max_retries, err, base_backoff)
                    print(f"[{self.name}] Job {job_id} failed (code {completed.returncode}).")
            except FileNotFoundError as e:
                err = str(e)
                update_job_on_failure(job_id, attempts, max_retries, err, base_backoff)
                print(f"[{self.name}] Job {job_id} failed (file not found). {err}")
            except Exception as e:
                err = str(e)
                update_job_on_failure(job_id, attempts, max_retries, err, base_backoff)
                print(f"[{self.name}] Job {job_id} failed (exception). {err}")
            finally:
                self.active_job = None
        print(f"[{self.name}] Shutting down worker thread.")

def start_workers(count):
    threads = []
    for i in range(count):
        t = WorkerThread(name=f"worker-{i+1}")
        t.start()
        threads.append(t)
    return threads

def stop_workers(threads, graceful_timeout=10):
    print("Stopping workers gracefully...")
    _stop_event.set()
    for t in threads:
        t.join(timeout=graceful_timeout)
    print("All workers stopped.")
