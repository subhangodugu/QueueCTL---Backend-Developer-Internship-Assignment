# queuectl.py
import click
import json
import uuid
import time
from db import init_db, enqueue_job, list_jobs, job_summary, set_config, get_config, force_retry_dlq
from worker import start_workers, stop_workers
from db import get_conn

_worker_threads = []

@click.group()
def cli():
    init_db()

@cli.command()
@click.argument('job_json', type=str)
def enqueue(job_json):
    """Enqueue a job JSON string. Example:
    queuectl enqueue '{"id":"job1","command":"sleep 2"}'
    """
    try:
        job = json.loads(job_json)
    except json.JSONDecodeError:
        click.echo("Invalid JSON")
        return
    if 'id' not in job:
        job['id'] = str(uuid.uuid4())
    if 'command' not in job:
        click.echo("Job must contain 'command'")
        return
    enqueue_job(job)
    click.echo(f"Enqueued job {job['id']}")

@cli.group()
def worker():
    """Worker commands"""
    pass

@worker.command('start')
@click.option('--count', default=1, help='Number of worker threads to start')
def worker_start(count):
    global _worker_threads
    if _worker_threads:
        click.echo("Workers already running in this process")
        return
    threads = start_workers(count)
    _worker_threads = threads
    click.echo(f"Started {count} worker(s). Press Ctrl+C to stop.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        stop_workers(threads)
        _worker_threads = []

@worker.command('stop')
def worker_stop():
    global _worker_threads
    if not _worker_threads:
        click.echo("No workers running in this process")
        return
    stop_workers(_worker_threads)
    _worker_threads = []

@cli.command()
def status():
    """Show job counts by state"""
    summary = job_summary()
    click.echo("Job counts by state:")
    for st in ['pending','processing','completed','failed','dead']:
        click.echo(f"  {st}: {summary.get(st, 0)}")
    click.echo(f"Active workers in this process: {len(_worker_threads)}")

@cli.command(name='list')
@click.option('--state', default=None, help='Filter by state (pending, processing, completed, dead)')
def list_cmd(state):
    """List jobs; optionally filter by state"""
    rows = list_jobs(state)
    if not rows:
        click.echo("No jobs")
        return
    for r in rows:
        click.echo(json.dumps(r, default=str))

@cli.group()
def dlq():
    """Dead Letter Queue operations"""
    pass

@dlq.command('list')
def dlq_list():
    rows = list_jobs('dead')
    if not rows:
        click.echo("DLQ empty")
        return
    for r in rows:
        click.echo(json.dumps(r, default=str))

@dlq.command('retry')
@click.argument('job_id')
def dlq_retry(job_id):
    ok = force_retry_dlq(job_id)
    if ok:
        click.echo(f"Job {job_id} moved out of DLQ to pending")
    else:
        click.echo(f"Job {job_id} not found in DLQ")

@cli.group()
def config():
    """Get/set configuration"""
    pass

@config.command('set')
@click.argument('key')
@click.argument('value')
def config_set(key, value):
    set_config(key, value)
    click.echo(f"Config {key} = {value}")

@config.command('get')
@click.argument('key')
def config_get(key):
    val = get_config(key)
    click.echo(f"{key} = {val}")

if __name__ == '__main__':
    cli()
