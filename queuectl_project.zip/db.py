# db.py
import sqlite3
import threading
import json
from datetime import datetime, timezone, timedelta

DB_FILENAME = "queue.db"
_db_lock = threading.Lock()

def _now_iso():
    return datetime.now(timezone.utc).isoformat()

def get_conn():
    conn = sqlite3.connect(DB_FILENAME, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with _db_lock:
        conn = get_conn()
        cur = conn.cursor()
        cur.execute("""
        CREATE TABLE IF NOT EXISTS jobs (
            id TEXT PRIMARY KEY,
            command TEXT NOT NULL,
            state TEXT NOT NULL,
            attempts INTEGER NOT NULL,
            max_retries INTEGER NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            available_at TEXT,
            last_error TEXT
        )
        """)
        cur.execute("""
        CREATE TABLE IF NOT EXISTS config (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
        """)
        defaults = {
            'backoff_base': '2',
            'default_max_retries': '3'
        }
        for k, v in defaults.items():
            cur.execute("INSERT OR IGNORE INTO config(key,value) VALUES (?,?)", (k, v))
        conn.commit()
        conn.close()

def set_config(key, value):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("INSERT OR REPLACE INTO config(key,value) VALUES (?,?)", (key, str(value)))
    conn.commit()
    conn.close()

def get_config(key, default=None):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT value FROM config WHERE key=?", (key,))
    row = cur.fetchone()
    conn.close()
    if row:
        return row['value']
    return default

def enqueue_job(job):
    conn = get_conn()
    cur = conn.cursor()
    now = _now_iso()
    max_retries = int(job.get('max_retries') or int(get_config('default_max_retries', '3')))
    cur.execute("""
        INSERT INTO jobs(id,command,state,attempts,max_retries,created_at,updated_at,available_at,last_error)
        VALUES (?,?,?,?,?,?,?,?,?)
    """, (
        job['id'], job['command'], 'pending', 0, max_retries, now, now, now, None
    ))
    conn.commit()
    conn.close()

def list_jobs(state=None):
    conn = get_conn()
    cur = conn.cursor()
    if state:
        cur.execute("SELECT * FROM jobs WHERE state=? ORDER BY created_at", (state,))
    else:
        cur.execute("SELECT * FROM jobs ORDER BY created_at")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows

def job_summary():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT state, COUNT(*) as cnt FROM jobs GROUP BY state")
    rows = cur.fetchall()
    conn.close()
    return {r['state']: r['cnt'] for r in rows}

def claim_next_pending(available_before_iso):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        SELECT id FROM jobs
        WHERE state='pending' AND (available_at IS NULL OR available_at <= ?)
        ORDER BY created_at LIMIT 1
    """, (available_before_iso,))
    row = cur.fetchone()
    if not row:
        conn.close()
        return None
    job_id = row['id']
    now = _now_iso()
    cur.execute("""
        UPDATE jobs SET state='processing', updated_at=? WHERE id=? AND state='pending'
    """, (now, job_id))
    if cur.rowcount == 0:
        conn.commit()
        conn.close()
        return None
    cur.execute("SELECT * FROM jobs WHERE id=?", (job_id,))
    job = dict(cur.fetchone())
    conn.commit()
    conn.close()
    return job

def update_job_on_success(job_id):
    conn = get_conn()
    cur = conn.cursor()
    now = _now_iso()
    cur.execute("UPDATE jobs SET state='completed', updated_at=? WHERE id=?", (now, job_id))
    conn.commit()
    conn.close()

def update_job_on_failure(job_id, attempts, max_retries, error_text, base_backoff):
    conn = get_conn()
    cur = conn.cursor()
    now = _now_iso()
    if attempts >= max_retries:
        cur.execute("""
            UPDATE jobs SET state='dead', attempts=?, last_error=?, updated_at=? WHERE id=?
        """, (attempts, error_text, now, job_id))
    else:
        delay_seconds = (float(base_backoff) ** attempts)
        available_at = (datetime.now(timezone.utc) + timedelta(seconds=delay_seconds)).isoformat()
        cur.execute("""
            UPDATE jobs SET state='pending', attempts=?, last_error=?, available_at=?, updated_at=? WHERE id=?
        """, (attempts, error_text, available_at, now, job_id))
    conn.commit()
    conn.close()

def force_retry_dlq(job_id):
    conn = get_conn()
    cur = conn.cursor()
    now = _now_iso()
    cur.execute("""
        UPDATE jobs SET state='pending', attempts=0, available_at=?, updated_at=?, last_error=NULL WHERE id=? AND state='dead'
    """, (now, now, job_id))
    affected = cur.rowcount
    conn.commit()
    conn.close()
    return affected > 0
